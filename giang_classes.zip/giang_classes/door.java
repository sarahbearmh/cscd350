public class door {
   private int open = 0; 	
	
   public int getOpen()
   {
      return this.open;
   }//end getOpen   
  
   public void setOpen(int open)
   {
      this.open = open;
   }//end setOpen
   
}//end class
	
