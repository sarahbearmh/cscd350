public class player {
   private String name; 	
	
   public int getName()
   {
      return this.name;
   }//end getOpen   
  
   public void setName(String name)
   {
      this.name = name;
   }//end setOpen
   
}//end class
	
