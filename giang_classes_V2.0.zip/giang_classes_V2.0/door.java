public class door {
   private boolean open; 
   
   public door()
   {
      open = true;
   }//end door	
	
   public boolean isOpen()
   {
      return this.open;
   }//end getOpen   
  
   public void setOpen(boolean open)
   {
      this.open = open;
   }//end setOpen
   
}//end class
	
