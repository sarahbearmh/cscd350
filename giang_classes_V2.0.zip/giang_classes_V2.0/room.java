public class room 
{
   private int numOfDoor;	
   
   public room(int door)
   {
      this.numOfDoor = door;
   }//end room
	
   public int getDoor()
   {
      return this.numOfDoor;
   }//end getDoor   
  
   public void setDoor(int door)
   {
      this.numOfDoor = door;
   }//end setDoor
   
}//end class
	
